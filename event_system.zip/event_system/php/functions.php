<?php
function sendRecoveryEmail($email, $code) {
    // Use mail() or PHPMailer here
    return true;
}

function sendRecoverySMS($number, $code) {
    // Integrate SMS API here (like Twilio)
    return true;
}
?>
